def stanje(kolicina):
    '''Funkcija vrne pravilno slovnično
    obliko podane količine.'''
    try:
        kolicina = str(kolicina)
        kolicina = int(kolicina)
    except ValueError:
        return 'Podana količina ni celo število.'
    if kolicina >= 1000000:
        return 'Tajkun'
    if kolicina < -300:
        return 'Ti si navadna zguba'
    vsota = abs(kolicina)
    if vsota % 100 == 1:
        return 'Stanje je {} evro.'.format(kolicina)
    elif vsota % 100 == 2:
        return 'Stanje je {} evra.'.format(kolicina)
    elif vsota % 100 == 3:
        return 'Stanje je {} evri.'.format(kolicina)
    elif vsota % 100 == 4:
        return 'Stanje je {} evre.'.format(kolicina)
    else:
        return 'Stanje je {} evrov.'.format(kolicina)
    
        
        
if __name__ == '__main__':
    print(stanje(1))
    print(stanje(5))
    print(stanje(-3))
    print(stanje(4))
    # vnos celih števil
    print(stanje('1'))
    print(stanje('-11'))
    print(stanje('101'))
    # vnos nizov, ki so cela števila
    print(stanje(1.2))
    # vnos realnega števila
    print(stanje(102))
    print(stanje('1000100'))
    print(stanje(1003))
    print(stanje(-1004))
    # vnos še nekaterih količin
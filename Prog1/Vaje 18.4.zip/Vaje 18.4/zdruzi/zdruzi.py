import sys
def zdruzi(dat1, dat2, nova_dat):
    '''Funkcija združi i-te vrstice
    datotek in jih zapiše v novo datoteko na i-ti vrstici.
    (če sta obe datoteki prazni, ju program vzame
    za legitimne, vendar je ustvarjena datoteka prazna).
    '''
    besedilo1 = open(dat1, 'r')
    besedilo2 = open(dat2, 'r')
    vrstice1 = besedilo1.read().strip().split('\n')
    vrstice2 = besedilo2.read().strip().split('\n')
    file = open(nova_dat, 'w')
    if len(vrstice1) == len(vrstice2):
        for i in range(len(vrstice1)):
            if vrstice1[i] != '':
                file.write(vrstice1[i] + ' ' + vrstice2[i] + '\n')
    else:
        file.write('Ni enako število vrstic!')
    file.close()
    
    
if __name__ == '__main__':
    zdruzi('dat1.txt', 'dat2.txt', 'zdruzi1.txt')
    # združitev dveh praznih datotek
    zdruzi('dat3.txt', 'dat4.txt', 'zdruzi2.txt')
    # združitev, ki imata enako število vrstic
    zdruzi('dat5.txt', 'dat6.txt', 'zdruzi3.txt')
    # združitev dveh datotek, kjer ima ena manj vrstic kot druga
        